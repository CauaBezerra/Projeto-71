import firebase from "firebase";
require("@firebase/firestore");

var firebaseConfig = {
  //Cole sua Configuração do Firebase aqui
  apiKey: "AIzaSyA6IMFrmSGrMuEg-ZGe1TWrs8iy6QHqDqA",
  authDomain: "projeto-71-51607.firebaseapp.com",
  projectId: "projeto-71-51607",
  storageBucket: "projeto-71-51607.appspot.com",
  messagingSenderId: "289476816508",
  appId: "1:289476816508:web:255b65a70ba6b0856ba3f9",
  measurementId: "G-Q84FSQ607V"
};

firebase.initializeApp(firebaseConfig);

export default firebase.firestore();
